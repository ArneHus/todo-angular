import { List } from "./list";

export interface Category {
  id: number;
  name: string;
}