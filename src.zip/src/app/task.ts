export interface Task {
  id: number;
  task: String;
  isImportant: boolean;
  finishDate: String;
  finished: boolean;
  orderValue: number;
  listId: number;
}