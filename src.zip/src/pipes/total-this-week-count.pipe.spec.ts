import { TotalThisWeekCountPipe } from './total-this-week-count.pipe';

describe('TotalThisWeekCountPipe', () => {
  it('create an instance', () => {
    const pipe = new TotalThisWeekCountPipe();
    expect(pipe).toBeTruthy();
  });
});
