import { TotalImportantCountPipe } from './total-important-count.pipe';

describe('TotalImportantCountPipe', () => {
  it('create an instance', () => {
    const pipe = new TotalImportantCountPipe();
    expect(pipe).toBeTruthy();
  });
});
