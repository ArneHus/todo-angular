import { FilterListsByCategoryPipe } from './filter-lists-by-category.pipe';

describe('FilterListsByCategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterListsByCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
