import { TotalCountPipe } from './total-count.pipe';

describe('TotalCountPipe', () => {
  it('create an instance', () => {
    const pipe = new TotalCountPipe();
    expect(pipe).toBeTruthy();
  });
});
